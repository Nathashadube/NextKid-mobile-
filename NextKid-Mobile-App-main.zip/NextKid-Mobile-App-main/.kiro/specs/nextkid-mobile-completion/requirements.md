# NextKid Mobile — Completion Requirements

## Overview

NextKid is a South African school marketplace mobile app built with React Native (Expo). The app is connected to a live microservices backend on AWS ECS via an Application Load Balancer. Auth is fully working via AWS Cognito. Core screens (login, listing, wishlist, orders) are functional.

This spec covers the remaining work to make the app fully functional and production-ready.

---

## Context

**Repo**: https://github.com/ctmazarura95/nextkid-mobile  
**Backend ALB**: `http://nextkid-production-alb-1485337033.af-south-1.elb.amazonaws.com`  
**Auth**: AWS Cognito pool `af-south-1_WLU6GeAmy` / client `6u40c3sg27jsffv9r0joeaif9s`  
**Region**: af-south-1 (Cape Town)

### What is already done
- Cognito sign up / sign in / sign out / password reset — fully working
- Profile get and update — working via user-service
- Listings browse, create, edit, delete — working via listing-service
- Wishlist — working via frontend-service
- Orders list, detail, pay (Stitch), confirm receipt, QR codes — working via order-service
- Location/school/address search — working via location-service
- PUDO locker picker — working via frontend-service
- All `api-client.ts` methods typed and mapped to correct ALB routes

### What still needs work
- Feed screen shows empty / errors (needs child_profiles + size_predictions tables)
- Children / size profiles screen not connected to live data
- Notifications screen not connected to live data
- TypeScript `unknown` types throughout — screens and api-client need proper domain types
- Missing loading states and error boundaries on several screens
- No `app.json` bundle identifiers set (needed for EAS Build / store submission)
- `eas.json` submit section has placeholder Apple/Google credentials

---

## Requirements

### REQ-1: Typed Domain Models

All API responses and screen state must use explicit TypeScript types instead of `unknown` or `Record<string, unknown>`.

**Acceptance criteria:**
- `src/shared/types.ts` defines `Listing`, `Order`, `Profile`, `School`, `ChildProfile`, `Notification`, `Wishlist`, `Locker`, `Offer` types
- `api-client.ts` uses these types as generics on all methods (e.g. `get<Listing[]>`)
- All screen `useState` calls use typed state — no `any` or `unknown` in JSX files
- `npx tsc --noEmit` passes with zero errors

### REQ-2: Feed Screen — Live Data

The Home tab feed must load real listings from the backend.

**Acceptance criteria:**
- Feed calls `GET /api/feed` and displays returned listings in a scrollable grid/list
- Each feed card shows: listing image, title, price, condition badge, seller suburb
- If feed returns 500 (DB tables not migrated), falls back to `GET /api/listings` with a banner informing the user
- Pull-to-refresh works
- Tapping a card navigates to `item/[id]`
- Empty state shown with a call-to-action when there are no listings

### REQ-3: Children / Size Profiles Screen — Live Data

The children.tsx screen must create, list, and update child profiles using the live user-service.

**Acceptance criteria:**
- `GET /api/children` loads all child profiles on screen focus
- Adding a child calls `POST /api/children` with `{ nickname, gender, dob, grade, popia_consent: true }`
- Adding sizes calls `POST /api/children/:id/sizes`
- Size prediction calls `GET /api/children/:id/prediction` and displays results
- If user-service returns 500 (table not ready), shows a "Coming soon" placeholder instead of crashing
- POPIA consent modal is shown before first child is added

### REQ-4: Notifications Screen — Live Data

The notifications screen must load and mark-as-read from the live backend.

**Acceptance criteria:**
- `GET /api/notifications` loads on screen focus
- Unread notifications show a visual indicator (dot or bold)
- Tapping a notification calls `PUT /api/notifications` to mark it read
- Empty state shown when inbox is empty
- If endpoint returns 500 (table not ready), shows "No notifications yet" without crashing

### REQ-5: Error Boundaries and Loading States

Every screen that fetches data must handle loading and error states gracefully.

**Acceptance criteria:**
- Loading spinner shown while any API call is in flight
- Network errors (`NETWORK_ERROR` errorCode) show a "Check your connection" message with a retry button
- Auth errors (`SESSION_EXPIRED`) redirect to the login screen automatically
- 500 errors from the backend show a human-readable message, not a raw error or blank screen
- No screen crashes the app on an unhandled promise rejection

### REQ-6: Image Upload Flow

Listing creation must upload images to S3 via presigned URLs before submitting the listing.

**Acceptance criteria:**
- `POST /api/upload` is called with `{ filename, contentType }` to get a presigned URL
- The image is PUT directly to S3 using the presigned URL (not through the ALB)
- The returned `publicUrl` is stored in the listing's `images` array
- Multiple images supported (up to 5)
- Upload progress indicator shown while uploading

### REQ-7: EAS Build Configuration

The app must be ready to produce installable test binaries.

**Acceptance criteria:**
- `app.json` has `ios.bundleIdentifier: "co.za.nextkid.app"` and `android.package: "co.za.nextkid.app"`
- `eas.json` build profiles work end-to-end: `npm run build:preview` succeeds
- Development profile builds a development client with the correct ALB URL
- Production profile uses `https://api.nextkid.co.za` as the API base URL
- `.gitignore` excludes `google-service-account.json` and `*.p8`

### REQ-8: Push Notification Token Registration

When a user signs in, their Expo push token must be saved to their profile.

**Acceptance criteria:**
- `registerForPushNotifications()` is called after successful sign-in
- The token is saved via `PUT /api/profile` with `{ expo_push_token: token }`
- On Android, the notification channel is created before requesting permission
- Gracefully skips registration if running in Expo Go simulator (no error thrown)
- Token is refreshed on each app launch if the stored token has changed

### REQ-9: Offline / No Connection Handling

The app must not show blank screens when there is no internet connection.

**Acceptance criteria:**
- On launch with no connection, a persistent banner is shown: "No internet connection"
- Cached data (wishlist, listings) is shown from AsyncStorage if available
- When connection is restored, data refreshes automatically
- The banner dismisses when connectivity returns

### REQ-10: App Store Submission Readiness

All metadata and assets needed for Play Store and App Store submission must be in place.

**Acceptance criteria:**
- App icon (1024×1024 px) present at `assets/images/icon.png`
- Splash screen image present at `assets/images/splash-icon.png`
- Android adaptive icon images present (foreground, background, monochrome)
- `app.json` version is `"1.0.0"` with `versionCode: 1` for Android
- Privacy policy URL configured (can be placeholder for now)
- Location permission description set: "NextKid uses your location to show listings from your area and school"
