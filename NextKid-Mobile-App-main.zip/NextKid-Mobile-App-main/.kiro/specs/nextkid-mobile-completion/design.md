# NextKid Mobile — Technical Design

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│                  NextKid Mobile App                  │
│                  (React Native + Expo)               │
│                                                      │
│  app/ (Expo Router screens)                          │
│    ├── index.tsx          Login / Signup             │
│    ├── onboarding.tsx     First-run profile setup    │
│    ├── (tabs)/            Main navigation            │
│    │   ├── index.tsx      Feed (home)                │
│    │   ├── sell.tsx       Create listing             │
│    │   ├── orders.tsx     Order history              │
│    │   ├── wishlist.tsx   Saved items                │
│    │   ├── notifications.tsx                         │
│    │   └── profile.tsx    Profile + settings         │
│    ├── item/[id].tsx      Listing detail             │
│    ├── checkout/[id].tsx  Checkout flow              │
│    ├── order/[id].tsx     Order detail + QR          │
│    └── children.tsx       Child size profiles        │
│                                                      │
│  src/lib/                                            │
│    ├── api-client.ts      All HTTP calls             │
│    ├── auth/cognito.ts    Cognito JWT management     │
│    ├── cart.ts            AsyncStorage cart          │
│    └── pushNotifications.ts                         │
│                                                      │
│  src/shared/              Domain types + constants   │
└────────────────────┬────────────────────────────────┘
                     │ HTTP  (Authorization: Bearer JWT)
                     ▼
┌─────────────────────────────────────────────────────┐
│   ALB: nextkid-production-alb-1485337033             │
│          .af-south-1.elb.amazonaws.com               │
│                                                      │
│  Path routing (ecs-services.tf):                     │
│  /api/locations/*  → location-service   (port 8080) │
│  /api/profile*     → user-service       (port 8080) │
│  /api/children*    → user-service       (port 8080) │
│  /api/account*     → user-service       (port 8080) │
│  /api/listings/*   → listing-service    (port 8080) │
│  /api/schools/*    → school-service     (port 8080) │
│  /api/orders/*     → order-service      (port 8080) │
│  /*                → frontend-service   (port 8080) │
└─────────────────────────────────────────────────────┘
```

## Domain Types Design (REQ-1)

All types live in `src/shared/types.ts`. The existing file has base types — extend them:

```typescript
// src/shared/types.ts additions

export interface ChildProfile {
  id: string;
  nickname: string;
  gender: 'boy' | 'girl' | 'other';
  dob: string;            // YYYY-MM-DD
  grade: string | null;
  child_sizes: ChildSize[];
  prediction?: SizePrediction | null;
}

export interface ChildSize {
  id: string;
  recorded_date: string;
  top_size: string;
  bottom_size: string;
  shoe_size: string;
  source: 'manual' | 'ai';
}

export interface SizePrediction {
  predicted_top: string;
  predicted_bottom: string;
  predicted_shoe: string;
  confidence_score: number;   // 0.0 – 1.0
  basis: 'curve_only' | 'multi_point';
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  body: string;
  read: boolean;
  created_at: string;
  data?: Record<string, unknown>;
}

export interface WishlistItem {
  id: string;
  listing_id: string;
  listing: Listing;
  created_at: string;
}

export interface Locker {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  distanceKm?: number;
}

export interface FeedItem extends Listing {
  relevance_score?: number;
}

export interface ApiHealth {
  status: 'ok' | 'degraded';
  timestamp: string;
}
```

## Feed Screen Design (REQ-2)

**Fallback strategy**: `GET /api/feed` → on 500 → `GET /api/listings` (public browse fallback)

```typescript
// Fetch order in app/(tabs)/index.tsx
async function loadFeed() {
  try {
    const items = await feedApi.get();
    setListings(items as FeedItem[]);
    setFallback(false);
  } catch (err) {
    if (err instanceof ApiError && err.statusCode === 500) {
      // Feed needs DB migration — fall back to raw listings
      const items = await listingsApi.list();
      setListings(items as FeedItem[]);
      setFallback(true);  // show banner
    } else {
      throw err;  // let error boundary handle it
    }
  }
}
```

**Feed card layout**: 2-column grid. Each card: image (4:3), title (1 line), price (bold crimson), suburb + condition badge.

## Error Handling Pattern (REQ-5)

Standardise across all screens with a shared hook:

```typescript
// src/lib/useApiCall.ts
export function useApiCall<T>(
  fn: () => Promise<T>,
  deps: unknown[] = []
): { data: T | null; loading: boolean; error: ApiError | null; refresh: () => void }
```

Error display rules:
- `NETWORK_ERROR` → "No internet connection. Pull to retry."
- `SESSION_EXPIRED` → auto-redirect to `/` (login)
- `statusCode >= 500` → "Something went wrong on our end. Try again."
- `statusCode === 404` → "Not found."
- `statusCode === 403` → "You don't have permission to do this."

## Image Upload Flow Design (REQ-6)

Current `sell.tsx` picks images but may not use presigned URLs. The correct flow:

```
1. User picks image from camera/gallery
2. POST /api/upload { filename, contentType } → { uploadUrl, publicUrl }
3. PUT uploadUrl (direct to S3, no auth header) with image binary
4. Store publicUrl in local state
5. On listing submit, send publicUrl array in listing body
```

The `uploadApi.presign()` method in `api-client.ts` is already wired. The PUT to S3 must NOT include the `Authorization` header — use a plain `fetch()` call.

## EAS Build Configuration Design (REQ-7)

### app.json additions needed
```json
{
  "expo": {
    "ios": {
      "bundleIdentifier": "co.za.nextkid.app"
    },
    "android": {
      "package": "co.za.nextkid.app",
      "versionCode": 1
    }
  }
}
```

### eas.json submit section
```json
{
  "submit": {
    "production": {
      "ios": {
        "appleId": "REPLACE_WITH_APPLE_ID",
        "ascAppId": "REPLACE_WITH_APP_STORE_CONNECT_ID",
        "appleTeamId": "REPLACE_WITH_TEAM_ID"
      },
      "android": {
        "serviceAccountKeyPath": "./google-service-account.json",
        "track": "internal"
      }
    }
  }
}
```

## Offline / Connectivity Design (REQ-9)

Use `@react-native-community/netinfo` (already a transitive dep via Expo):

```typescript
// src/lib/useNetworkStatus.ts
import NetInfo from '@react-native-community/netinfo';

export function useNetworkStatus(): boolean  // returns isConnected
```

Cache strategy:
- Wishlist → `AsyncStorage` key `nextkid_wishlist_cache`
- Listings (last page) → `AsyncStorage` key `nextkid_listings_cache`
- Both written on successful fetch, read as initial state on next launch

## File Structure Changes

```
src/
├── lib/
│   ├── api-client.ts          (update generics to use domain types)
│   ├── auth/cognito.ts        (no changes needed)
│   ├── cart.ts                (no changes needed)
│   ├── pushNotifications.ts   (minor: handle token refresh)
│   ├── useApiCall.ts          (NEW — shared data-fetching hook)
│   └── useNetworkStatus.ts    (NEW — connectivity monitor)
└── shared/
    ├── types.ts               (extend with ChildProfile, Notification, etc.)
    ├── constants.ts           (no changes needed)
    ├── pricing.ts             (no changes needed)
    └── types/
        ├── shipping.ts        (no changes needed)
        └── location.ts        (no changes needed)
```

## Cognito Pool Reference

These values are correct and must not be changed. They are shared across all services.

| Config | Value |
|---|---|
| User Pool ID | `af-south-1_WLU6GeAmy` |
| Client ID | `6u40c3sg27jsffv9r0joeaif9s` |
| Region | `af-south-1` |
| Issuer | `https://cognito-idp.af-south-1.amazonaws.com/af-south-1_WLU6GeAmy` |

## Design Decisions

- **No Redux / Zustand** — screens manage their own state with `useState` + `useApiCall` hook. Only the cart uses a shared store (already AsyncStorage-based).
- **No React Query** — keep it minimal. The `useApiCall` hook is sufficient.
- **TypeScript strict mode** — already enabled in `tsconfig.json`. All new code must pass `tsc --noEmit`.
- **No new dependencies** — use what Expo SDK already ships. If something is genuinely needed, flag it first.
- **Error boundaries** — use React's `ErrorBoundary` pattern. `app/_layout.tsx` already exports one from expo-router.
