# NextKid Mobile — Implementation Tasks

## Task 1: Add Domain Types to src/shared/types.ts

**Requirement**: REQ-1  
**File**: `src/shared/types.ts`

Add the following types to the existing file (do not remove existing types):

- `ChildProfile` — id, nickname, gender ('boy'|'girl'|'other'), dob, grade, child_sizes, prediction
- `ChildSize` — id, recorded_date, top_size, bottom_size, shoe_size, source
- `SizePrediction` — predicted_top, predicted_bottom, predicted_shoe, confidence_score (0-1), basis
- `Notification` — id, user_id, type, title, body, read (boolean), created_at, optional data
- `WishlistItem` — id, listing_id, listing (Listing type), created_at
- `Locker` — id, name, address, lat, lng, optional distanceKm
- `FeedItem` — extends Listing, optional relevance_score
- `ApiHealth` — status ('ok'|'degraded'), timestamp

**Acceptance**: `npx tsc --noEmit` passes after this task.

---

## Task 2: Update api-client.ts with Domain Types

**Requirement**: REQ-1  
**File**: `src/lib/api-client.ts`

Replace all `unknown`, `Record<string, unknown>`, and `unknown[]` return types with the proper domain types from `src/shared/types.ts`. Specific changes:

- `profileApi.get()` → `Promise<Profile>`
- `profileApi.update()` → `Promise<Profile>`
- `listingsApi.list()` → `Promise<Listing[]>`
- `listingsApi.get()` → `Promise<Listing>`
- `listingsApi.create()` → `Promise<Listing>`
- `listingsApi.update()` → `Promise<Listing>`
- `feedApi.get()` → `Promise<FeedItem[]>`
- `wishlistApi.list()` → `Promise<WishlistItem[]>`
- `ordersApi.list()` → `Promise<Order[]>`
- `ordersApi.get()` → `Promise<Order>`
- `ordersApi.create()` → `Promise<Order>`
- `childrenApi.list()` → `Promise<ChildProfile[]>`
- `childrenApi.get()` → `Promise<ChildProfile>`
- `childrenApi.create()` → `Promise<ChildProfile>`
- `childrenApi.addSize()` → `Promise<ChildSize>`
- `childrenApi.prediction()` → `Promise<SizePrediction>`
- `notificationsApi.list()` → `Promise<Notification[]>`
- `lockersApi.nearby()` → `Promise<{ lockers: Locker[] }>`
- `schoolsApi.list()` → `Promise<School[]>`
- `schoolsApi.get()` → `Promise<School>`
- `checkBackendHealth()` → already returns `Promise<boolean>`, no change needed

**Acceptance**: `npx tsc --noEmit` passes. No `unknown` or `any` in api-client.ts.

---

## Task 3: Create useApiCall Hook

**Requirement**: REQ-5  
**New file**: `src/lib/useApiCall.ts`

Create a hook with this signature:

```typescript
export function useApiCall<T>(
  fn: () => Promise<T>,
  deps?: unknown[]
): {
  data: T | null;
  loading: boolean;
  error: ApiError | null;
  refresh: () => void;
}
```

Behaviour:
- Calls `fn()` on mount and whenever `deps` change
- Sets `loading: true` while the call is in flight
- On success: sets `data`, clears `error`, sets `loading: false`
- On `SESSION_EXPIRED` ApiError: calls `signOut()` then navigates to `/` using `useRouter`
- On `NETWORK_ERROR` ApiError: sets `error`, sets `loading: false`, does NOT redirect
- On any other ApiError: sets `error`, sets `loading: false`
- `refresh()` re-invokes `fn()` manually

---

## Task 4: Create useNetworkStatus Hook

**Requirement**: REQ-9  
**New file**: `src/lib/useNetworkStatus.ts`

Create a hook that returns `{ isConnected: boolean }`. Use `NetInfo` from `@react-native-community/netinfo` (available via Expo). Subscribe to network state changes and update accordingly. Initial state should assume connected until first NetInfo response.

---

## Task 5: Add Network Banner to Root Layout

**Requirement**: REQ-9  
**File**: `app/_layout.tsx`

Import `useNetworkStatus`. When `isConnected` is false, render a persistent red banner at the top of the screen (below the status bar) with text "No internet connection". The banner should animate in/out using `Animated.timing` with 200ms duration. Use `StyleSheet` — no inline styles. The banner must not cover tab content when hidden.

---

## Task 6: Fix Feed Screen — Live Data with Fallback

**Requirement**: REQ-2  
**File**: `app/(tabs)/index.tsx`

Rewrite the data-fetching logic using `useApiCall`:

1. Try `feedApi.get()` first
2. If it throws an `ApiError` with `statusCode === 500`, call `listingsApi.list()` as fallback and set a `isFallback` state flag
3. If `isFallback` is true, show a yellow info banner: "Showing all listings — personalised feed coming soon"
4. Render listings in a 2-column `FlatList` grid
5. Each card: listing image (use `Image` with the first item in `listing.images`), title (1 line, truncated), price formatted as "R {price/100}" in crimson, condition badge, seller suburb
6. Tapping a card navigates to `/item/${listing.id}`
7. Include pull-to-refresh (`RefreshControl`)
8. Show empty state with text "No listings yet" and a "Sell something" button linking to the sell tab when the list is empty
9. Show loading spinner (`ActivityIndicator`) while fetching
10. Show error state with retry button on network errors

---

## Task 7: Fix Notifications Screen — Live Data

**Requirement**: REQ-4  
**File**: `app/(tabs)/notifications.tsx`

Replace any placeholder/mock data with live API calls:

1. Call `notificationsApi.list()` on screen focus using `useFocusEffect`
2. Render each notification: title (bold), body, timestamp (formatted as relative time e.g. "2 hours ago")
3. Unread notifications have a crimson dot on the left and a slightly off-white background (`#fafafa`)
4. Tapping a notification calls `notificationsApi.markAsRead([notification.id])` and updates local state
5. "Mark all as read" button in the header that calls `notificationsApi.markAsRead()` with no ids (all)
6. If the endpoint returns `statusCode === 500`, show: "Notifications coming soon" with a bell icon — do not show an error
7. Empty state: bell icon with "You're all caught up"
8. Pull-to-refresh

---

## Task 8: Fix Children Screen — Live Data

**Requirement**: REQ-3  
**File**: `app/children.tsx`

The screen already has a complete UI. Wire it to the live API:

1. On mount, call `childrenApi.list()` — replace any hardcoded or demo data
2. Adding a child calls `childrenApi.create({ nickname, gender, dob, grade, popia_consent: true })`
3. Adding sizes calls `childrenApi.addSize(child.id, { top_size, bottom_size, shoe_size })`
4. Prediction button calls `childrenApi.prediction(child.id)`
5. If any call returns `statusCode === 500`, show a "Children profiles coming soon — backend migration in progress" placeholder card instead of the add-child button
6. Map all API response fields to the `ChildProfile` type from Task 1

---

## Task 9: Fix Image Upload in Sell Screen

**Requirement**: REQ-6  
**File**: `app/(tabs)/sell.tsx`

Audit the current image handling. If images are being passed as local URIs to the listing create call, fix the flow:

1. When a user picks an image, call `uploadApi.presign({ filename: '<uuid>.jpg', contentType: 'image/jpeg' })`
2. Use the returned `uploadUrl` to PUT the image binary directly to S3 — use plain `fetch()` with `Content-Type: image/jpeg` header and NO `Authorization` header
3. Store the `publicUrl` in component state
4. Pass the `publicUrl` array in the listing create body
5. Show a per-image upload progress indicator (can be a simple ActivityIndicator overlay on the image thumbnail)
6. Disable the "List Item" submit button until all images have finished uploading

---

## Task 10: Set Bundle Identifiers in app.json

**Requirement**: REQ-7, REQ-10  
**File**: `app.json`

Add the following fields:

```json
{
  "expo": {
    "ios": {
      "bundleIdentifier": "co.za.nextkid.app",
      "supportsTablet": true,
      "infoPlist": {
        "NSLocationWhenInUseUsageDescription": "NextKid uses your location to show listings from your area and school."
      }
    },
    "android": {
      "package": "co.za.nextkid.app",
      "versionCode": 1
    }
  }
}
```

Do not change any existing fields — only add the missing ones.

---

## Task 11: Fix Push Notification Token Registration

**Requirement**: REQ-8  
**File**: `src/lib/pushNotifications.ts`

The function already exists. Verify and fix:

1. `Notifications.setNotificationChannelAsync` is called on Android before requesting permission
2. After getting the Expo push token, call `profileApi.update({ expo_push_token: token })`
3. Wrap the entire function in a try/catch — any error must be silently logged, never thrown
4. The function must work even when running in Expo Go (no physical push token available) — detect with `Device.isDevice` from `expo-device` and skip gracefully if false

---

## Task 12: TypeScript Cleanup Pass

**Requirement**: REQ-1  
**Files**: All `app/**/*.tsx` and `src/**/*.ts` files

After Tasks 1-11 are done:

1. Run `npx tsc --noEmit` and fix every remaining error
2. Replace any remaining `any` type with the correct type
3. Replace any remaining `unknown[]` cast with the typed array from Task 1
4. Ensure all `useState` calls have explicit type parameters where the initial value is `null` or `[]`

**Acceptance**: `npx tsc --noEmit` exits with code 0, zero errors.

---

## Task 13: Commit and Push All Changes

After all tasks above are complete and `npx tsc --noEmit` passes:

1. Stage all changed files: `git add -A`
2. Create a single commit:
   ```
   feat: complete mobile app — typed models, live feed/notifications/children, image upload, EAS config
   
   - REQ-1: Domain types added, api-client fully typed, tsc passes clean
   - REQ-2: Feed loads from /api/feed with /api/listings fallback
   - REQ-3: Children screen wired to live user-service
   - REQ-4: Notifications screen wired to live backend
   - REQ-5: useApiCall hook, error boundaries, session expiry auto-redirect
   - REQ-6: Image upload via presigned S3 URLs
   - REQ-7: app.json bundle identifiers set, EAS build profiles verified
   - REQ-8: Push token registration fixed, Expo Go safe
   - REQ-9: Network banner via useNetworkStatus
   - REQ-10: Store submission assets verified
   ```
3. Push to origin: `git push origin main`
